﻿// src/pages/ReactLifecycle.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function ReactLifecycle() {
    const cards = [
        {
            title: "Was ist der React Lifecycle?",
            body: (
                <>
                    Der **Lifecycle** einer React-Komponente beschreibt die verschiedenen Phasen,
                    die eine Komponente durchläuft, von der Erstellung bis zu ihrer Zerstörung.
                    <br /><br />
                    React bietet spezielle Methoden und Hooks, die es ermöglichen, in jeder dieser
                    Phasen auf den Zustand der Komponente zuzugreifen und auf Änderungen zu reagieren.
                </>
            ),
        },
        {
            title: "Die 3 Hauptphasen des Components-Lifecycle",
            body: (
                <>
                    <ul>
                        <li><strong>Mounting:</strong> Die Phase, in der eine Komponente zum ersten Mal ins DOM eingefügt wird.</li>
                        <li><strong>Updating:</strong> Wenn sich der Zustand oder die Props der Komponente ändern, wird sie neu gerendert.</li>
                        <li><strong>Unmounting:</strong> Wenn die Komponente aus dem DOM entfernt wird.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Reconciliation Prozess",
            body: (
                <>
                    <ul>
                        <li><strong>Reconciliation:</strong> Der Prozess, bei dem React prüft, welche Teile des Virtual DOMs geändert wurden und diese dann im echten DOM anwendet.</li>
                        <li>Dieser Prozess sorgt für **Performance-Optimierungen** durch das Minimieren unnötiger DOM-Updates.</li>
                        <li>React nutzt den Virtual DOM und vergleicht den alten mit dem neuen Zustand der Komponente, um effizient Updates vorzunehmen.</li>
                    </ul>
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
