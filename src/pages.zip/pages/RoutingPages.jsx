﻿// src/pages/RoutingPages.jsx
import React from "react";
import "./PageStyles.css";

export default function RoutingPages() {
    return (
        <>
            <div className="page-grid">
                {/* Karte 1 */}
                <div className="page-card">
                    <h3 className="card-title">React Router Setup</h3>
                    <ul className="card-body">
                        <li>Installation: <code>npm install react-router-dom</code></li>
                        <li>BrowserRouter in <code>main.jsx</code> einbinden</li>
                        <li><code>&lt;Routes&gt;</code> und <code>&lt;Route&gt;</code> definieren</li>
                    </ul>
                </div>

                {/* Karte 2 */}
                <div className="page-card">
                    <h3 className="card-title">Dynamische Routen</h3>
                    <ul className="card-body">
                        <li>Pfad-Parameter: <code>/users/:id</code></li>
                        <li>Hook <code>useParams()</code> zum Auslesen</li>
                    </ul>
                </div>

                {/* Karte 3 */}
                <div className="page-card">
                    <h3 className="card-title">Verschachtelte Routen</h3>
                    <ul className="card-body">
                        <li>Nested <code>&lt;Route&gt;</code> innerhalb von Layouts</li>
                        <li><code>&lt;Outlet /&gt;</code> für Unterseiten</li>
                    </ul>
                </div>

                {/* Karte 4 */}
                <div className="page-card">
                    <h3 className="card-title">Navigation</h3>
                    <ul className="card-body">
                        <li><code>&lt;Link to="..."&gt;</code> für interne Links</li>
                        <li>Programmatisch mit <code>useNavigate()</code></li>
                    </ul>
                </div>

                {/* Karte 5 */}
                <div className="page-card">
                    <h3 className="card-title">404 &amp; Redirects</h3>
                    <ul className="card-body">
                        <li><code>path="*"</code> für No-Match-Seite</li>
                        <li><code>&lt;Navigate to="/" replace /&gt;</code> für Weiterleitungen</li>
                    </ul>
                </div>

                {/* Karte 6 */}
                <div className="page-card">
                    <h3 className="card-title">Beispiel-Code</h3>
                    <pre className="code-snippet">
{`<Routes>
  <Route path="/" element={<Home />} />
  <Route path="about" element={<About />} />
  <Route path="users/:id" element={<User />} />
  <Route path="*" element={<NotFound />} />
</Routes>`}
          </pre>
                </div>
            </div>
        </>
    );
}
