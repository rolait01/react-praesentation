﻿// src/pages/StateManagement.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function StateManagement() {
    const cards = [
        {
            title: "Was ist State Management?",
            body: (
                <>
                    **State Management** ist der Prozess, bei dem der Zustand innerhalb einer Anwendung verwaltet wird.
                    <br /><br />
                    In React ist **State** eine der wichtigsten Funktionen, die es einer Komponente ermöglicht, auf Eingaben und Interaktionen zu reagieren und ihren Status zu ändern.
                </>
            ),
        },
        {
            title: "useState Hook",
            body: (
                <>
                    <ul>
                        <li><strong>useState:</strong> Der grundlegende Hook in React, um den Zustand in einer funktionalen Komponente zu verwalten.</li>
                        <li>Er wird verwendet, um einen Wert zu speichern und diesen im Laufe der Zeit zu ändern.</li>
                        <li>Jeder Zustand, der in einer Komponente verwendet wird, muss durch `useState` definiert werden.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "useEffect Hook",
            body: (
                <>
                    <ul>
                        <li><strong>useEffect:</strong> Ein Hook, der es dir ermöglicht, Nebenwirkungen wie API-Aufrufe, Timer oder DOM-Manipulationen in funktionalen Komponenten zu verwalten.</li>
                        <li>Dieser Hook wird häufig verwendet, um den Zustand nach einer Änderung zu synchronisieren oder bei der Initialisierung Daten zu laden.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Context API für globalen Zustand",
            body: (
                <>
                    <ul>
                        <li><strong>Context API:</strong> Ein eingebauter React-Mechanismus, um globalen Zustand zwischen Komponenten zu teilen.</li>
                        <li>Verhindert „Props-Drilling“, indem Daten über den gesamten Komponentenbaum hinweg zugänglich gemacht werden.</li>
                        <li>Ideal für kleinere bis mittlere React-Anwendungen, die keinen Zustandsspeicher wie Redux benötigen.</li>
                    </ul>
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
