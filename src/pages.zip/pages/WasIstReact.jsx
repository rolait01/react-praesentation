﻿// src/pages/WasIstReact.jsx
import React, { useState } from "react";
import "../pages/PageStyles.css";

export default function WasIstReact() {
    const [currentCard, setCurrentCard] = useState(0);

    const cards = [
        {
            title: "Was ist React?",
            body: (
                <>
                    <ul>
                        <li>JavaScript-Bibliothek für UI-Entwicklung</li>
                        <li>Erstellt von Facebook, Open-Source seit 2013</li>
                        <li>Fokus auf Komponenten und Wiederverwendbarkeit</li>
                        <li>Verwendet JSX für deklarative UI-Beschreibung</li>
                        <li>Optimiert mit Virtual DOM für schnelle Updates</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Zeige ein einfaches Diagramm, das den Unterschied zwischen Virtual DOM und Real DOM visualisiert.</p>
                </>
            ),
        },
        {
            title: "Virtual DOM",
            body: (
                <>
                    <ul>
                        <li>Leichtgewichtige Kopie des echten DOM</li>
                        <li>Veränderungen werden zunächst im Virtual DOM berechnet</li>
                        <li>Erst dann werden Änderungen im echten DOM vorgenommen</li>
                        <li>Erhöht die Performance durch Minimierung von DOM-Updates</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Diagramm, das den Prozess der Veränderung im Virtual DOM und den Vergleich zum echten DOM zeigt.</p>
                </>
            ),
        },
        {
            title: "Komponentenstruktur",
            body: (
                <>
                    <ul>
                        <li>UI wird in kleine, wiederverwendbare Komponenten unterteilt</li>
                        <li>Jede Komponente hat ihre eigene Logik und Darstellung</li>
                        <li>Fördert Wiederverwendbarkeit und klare Trennung</li>
                        <li>Erleichtert Wartung und Testbarkeit</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Visualisiere eine Komponentenhierarchie oder das "Parent-Child"-Verhältnis von Komponenten.</p>
                </>
            ),
        },
        {
            title: "JSX-Syntax",
            body: (
                <>
                    <ul>
                        <li>JSX ist eine Erweiterung von JavaScript</li>
                        <li>Erlaubt HTML-ähnliche Syntax im Code</li>
                        <li>Ermöglicht das Erstellen von React-Komponenten mit deklarativem HTML</li>
                        <li>JSX wird in normalen JavaScript-Code umgewandelt</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Ein Beispiel für JSX-Code und die Ausgabe im Browser.</p>
                </>
            ),
        },
        {
            title: "One-Way Data Flow",
            body: (
                <>
                    <ul>
                        <li>Daten fließen immer von Eltern- zu Kindkomponenten</li>
                        <li>Vereinfachte Nachvollziehbarkeit des Datenflusses</li>
                        <li>Erhöht die Vorhersagbarkeit und Kontrolle</li>
                        <li>Verhindert unerwartete Nebeneffekte</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Zeige den Datenfluss in einem einfachen Diagramm – von der obersten bis zur untersten Komponente.</p>
                </>
            ),
        },
        {
            title: "React Router",
            body: (
                <>
                    <ul>
                        <li>Verwendet für das Routing innerhalb einer React-App</li>
                        <li>Unterstützt dynamisches Laden von Komponenten je nach URL</li>
                        <li>Keine Seitenneuladung – nur die Komponenten werden geändert</li>
                        <li>Optimiert für Single Page Applications (SPA)</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Eine Darstellung der URL-Änderung und wie der Router die passenden Komponenten lädt.</p>
                </>
            ),
        },
        {
            title: "Hooks – useState & useEffect",
            body: (
                <>
                    <ul>
                        <li><strong>useState:</strong> Verwaltet den Zustand in funktionalen Komponenten</li>
                        <li><strong>useEffect:</strong> Ermöglicht den Zugriff auf Lebenszyklusmethoden</li>
                        <li>Hooks ermöglichen es, Logik ohne Klassenkomponenten zu verwalten</li>
                        <li>Verhindert die Notwendigkeit für Klassenkomponenten und vereinfacht den Code</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Visualisiere den Unterschied zwischen Klassenkomponenten und funktionalen Komponenten mit Hooks.</p>
                </>
            ),
        },
        {
            title: "State Management mit Context und Redux",
            body: (
                <>
                    <ul>
                        <li><strong>Context API:</strong> Teilt globalen Zustand ohne Props-Drilling</li>
                        <li><strong>Redux:</strong> Zentralisierte Store-Datenbank für den Zustand</li>
                        <li>Mit Redux können Daten effizient und vorhersehbar verwaltet werden</li>
                        <li>Context eignet sich für kleinere Apps, Redux für komplexe Anwendungen</li>
                    </ul>
                    <p><strong>Grafik-Empfehlung:</strong> Zeige den Unterschied zwischen Context und Redux, z. B. in einem Diagramm der Zustandshierarchie.</p>
                </>
            ),
        },
    ];

    const handleCardClick = () => {
        setCurrentCard((prevCard) => (prevCard + 1) % cards.length);
    };

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                <div className="react-card" onClick={handleCardClick}>
                    <h2 className="card-title">{cards[currentCard].title}</h2>
                    <div className="card-body">{cards[currentCard].body}</div>
                </div>
            </div>
        </div>
    );
}
