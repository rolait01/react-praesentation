﻿// src/pages/PerformanceOptimization.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function PerformanceOptimization() {
    const cards = [
        {
            title: "Warum ist Performance in React wichtig?",
            body: (
                <>
                    In React-Anwendungen sind Performance und Ladegeschwindigkeit entscheidend, um eine
                    **gute Benutzererfahrung** zu gewährleisten. Ohne Optimierungen können große und komplexe
                    Anwendungen langsam werden und die Ladezeiten verlängern.
                </>
            ),
        },
        {
            title: "useMemo und useCallback",
            body: (
                <>
                    <ul>
                        <li><strong>useMemo:</strong> Verhindert unnötige Berechnungen, indem er nur dann eine
                            Funktion ausführt, wenn sich die Eingabewerte ändern.</li>
                        <li><strong>useCallback:</strong> Verhindert das Neu-Erstellen von Funktionen, wenn sich
                            die Abhängigkeiten nicht geändert haben.</li>
                    </ul>
                    <br />
                    Diese Hooks sind besonders nützlich, wenn du teure Berechnungen oder Funktionen in
                    deiner Anwendung hast.
                </>
            ),
        },
        {
            title: "Lazy Loading und Code-Splitting",
            body: (
                <>
                    <ul>
                        <li><strong>Lazy Loading:</strong> Teile deiner Anwendung werden nur dann geladen, wenn
                            sie benötigt werden, um die Initial-Ladezeit zu verkürzen.</li>
                        <li><strong>Code-Splitting:</strong> Große JavaScript-Dateien werden in kleinere
                            Teile zerlegt, die nur bei Bedarf geladen werden.</li>
                    </ul>
                    <br />
                    **React.lazy** und **Suspense** können verwendet werden, um Komponenten nur dann zu laden,
                    wenn sie benötigt werden.
                </>
            ),
        },
        {
            title: "React PureComponent und React.memo",
            body: (
                <>
                    <ul>
                        <li><strong>React.PureComponent:</strong> Eine optimierte Version von React.Component,
                            die verhindert, dass Komponenten neu gerendert werden, wenn sich der **State** und die
                            **Props** nicht geändert haben.</li>
                        <li><strong>React.memo:</strong> Ein höherwertiger Komponentenhoc, der verhindert, dass
                            funktionale Komponenten unnötig neu gerendert werden, wenn sich ihre Props nicht ändern.</li>
                    </ul>
                    <br />
                    Diese Methoden helfen dabei, unnötige Re-Renders zu vermeiden und die Performance zu
                    verbessern.
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
