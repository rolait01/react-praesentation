﻿import React from "react";
import "./PageStyles.css";

export default function StateProps() {
    return (
        <div className="page-content">
            <div className="page-grid">
                <div className="page-card">
                    <h3 className="card-title">State – Was ist das?</h3>
                    <ul className="card-body bullet-list">
                        <li>Lokaler Zustand in der Komponente.</li>
                        <li>useState Hook liefert Wert + Setter.</li>
                        <li>Änderungen triggern Re-Render.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Props – Was sind das?</h3>
                    <ul className="card-body bullet-list">
                        <li>Props = Daten von Eltern → Kind.</li>
                        <li>Unidirektionaler Fluss.</li>
                        <li>Unveränderlich in Kind-Komponente.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">useState-Beispiel</h3>
                    <pre className="code-snippet">
{`import { useState } from "react";

function Counter() {
  const [count, setCount] = useState(0);
  return (
    <button onClick={() => setCount(c => c + 1)}>
      Klicks: {count}
    </button>
  );
}`}
          </pre>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Lifting State Up</h3>
                    <ul className="card-body bullet-list">
                        <li>State in gemeinsames Eltern-Element verlagern.</li>
                        <li>Props an mehrere Kinder weiterreichen.</li>
                        <li>Synchronisierte Daten.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">State &amp; Props zusammen</h3>
                    <ul className="card-body bullet-list">
                        <li>State hält Werte, Props verteilen sie.</li>
                        <li>Pure Komponenten nur mit Props.</li>
                        <li>Komplexe Logik im State-Manager.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Best Practices</h3>
                    <ul className="card-body bullet-list">
                        <li>State minimal halten.</li>
                        <li>Props für Lesbarkeit typisieren.</li>
                        <li>Hooks in Top-Level aufrufen.</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}
