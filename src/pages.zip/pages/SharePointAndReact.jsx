﻿// src/pages/SharePointAndReact.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function SharePointAndReact() {
    const cards = [
        {
            title: "Warum React mit SharePoint?",
            body: (
                <>
                    React ist eine **moderne Frontend-Bibliothek**, die es ermöglicht, **interaktive Benutzeroberflächen** zu erstellen. In Verbindung mit SharePoint wird React häufig verwendet, um die Benutzererfahrung zu verbessern.
                    <br /><br />
                    Vorteile der Verwendung von React mit SharePoint:
                    <ul>
                        <li>Erhöhte **Interaktivität** und bessere **Performance**</li>
                        <li>**Wiederverwendbare Komponenten** für eine saubere und modulare Struktur</li>
                        <li>Verbesserte **Benutzererfahrung** durch **Single-Page-Applications (SPA)**</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Integration von React in SharePoint",
            body: (
                <>
                    Die **Integration von React in SharePoint** erfolgt über das **SharePoint Framework (SPFx)**. Mit SPFx können moderne Webparts erstellt werden, die **React** als Frontend verwenden.
                    <br /><br />
                    Mit SPFx kannst du:
                    <ul>
                        <li>**SharePoint-Listen und -Bibliotheken** in deine React-Komponenten integrieren.</li>
                        <li>**Reaktive und interaktive UIs** für SharePoint-Seiten erstellen.</li>
                        <li>**Wiederverwendbare Komponenten** entwickeln, die in mehreren SharePoint-Webparts eingesetzt werden können.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Erstellung von SharePoint Webparts mit React",
            body: (
                <>
                    Um ein **React Webpart** in SharePoint zu erstellen, benötigst du das **SharePoint Framework (SPFx)**.
                    <br /><br />
                    Schritte zur Erstellung eines React Webparts:
                    <ul>
                        <li>Installiere **SPFx** über den Befehl: `yo @microsoft/sharepoint`</li>
                        <li>Wähle **React** als Framework bei der Erstellung des Projekts aus.</li>
                        <li>Erstelle deine React-Komponenten und baue sie in SPFx ein.</li>
                        <li>Veröffentliche das Webpart im SharePoint Online.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Kommunikation mit SharePoint-Daten",
            body: (
                <>
                    React-Webparts können **Daten aus SharePoint** über die **SharePoint REST API** oder die **Graph API** abrufen.
                    <br /><br />
                    Beispiel für den Abruf von Daten aus einer SharePoint-Liste:
                    <pre>{`fetch('https://<tenant>.sharepoint.com/_api/web/lists/getbytitle('ListName')/items')`}</pre>
                    <br /><br />
                    Mit diesen APIs kannst du Daten aus **Listen** und **Bibliotheken** abrufen und sie dynamisch in deine React-Komponenten einbinden.
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
