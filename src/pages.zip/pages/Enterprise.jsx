﻿import React from "react";
import "./PageStyles.css";

export default function Enterprise() {
    return (
        <>
            <div className="page-grid">
                <div className="page-card">
                    <h3 className="card-title">Monorepo</h3>
                    <ul className="card-body">
                        <li>Mehrere Packages</li>
                        <li>Yarn Workspaces</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">CI / CD</h3>
                    <ul className="card-body">
                        <li>Automatisierte Tests</li>
                        <li>Deployment Pipelines</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Testing</h3>
                    <ul className="card-body">
                        <li>Jest & RTL</li>
                        <li>End-to-End (Cypress)</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Performance</h3>
                    <ul className="card-body">
                        <li>Code-Splitting</li>
                        <li>Lazy Loading</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Accessibility</h3>
                    <ul className="card-body">
                        <li>ARIA-Attribute</li>
                        <li>Screenreader-Support</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Internationalisierung</h3>
                    <ul className="card-body">
                        <li>react-intl / i18next</li>
                        <li>Sprachfallbacks</li>
                    </ul>
                </div>
            </div>
        </>
    );
}
