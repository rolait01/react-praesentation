﻿// src/pages/Components.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function Components() {
    const cards = [
        {
            title: "Was sind Komponenten?",
            body: (
                <>
                    In React sind **Komponenten** die grundlegenden Bausteine für die UI einer Anwendung.
                    Eine Komponente kann eine ganze Seite, ein Formular oder sogar ein Button sein.
                    <br /><br />
                    Sie kapseln sowohl die Logik als auch das Layout und sind unabhängig und wiederverwendbar.
                </>
            ),
        },
        {
            title: "Arten von Komponenten",
            body: (
                <>
                    Es gibt zwei Hauptarten von Komponenten:
                    <ul>
                        <li><strong>Funktionale Komponenten:</strong> Einfachere und kürzere Komponenten, die mit React Hooks arbeiten.</li>
                        <li><strong>Klassenbasierte Komponenten:</strong> Älterer Ansatz, der mit Lifecycle-Methoden arbeitet.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Props und State",
            body: (
                <>
                    Komponenten können über **Props** Daten von übergeordneten Komponenten empfangen und durch **State** ihren eigenen Zustand verwalten.
                    <br /><br />
                    - **Props:** Übertragen Daten an untergeordnete Komponenten.
                    <br />
                    - **State:** Verwaltet den Zustand innerhalb einer Komponente und kann dynamisch verändert werden.
                </>
            ),
        },
        {
            title: "Wiederverwendbarkeit und Modularität",
            body: (
                <>
                    Eine der größten Stärken von React-Komponenten ist ihre Wiederverwendbarkeit.
                    <br /><br />
                    Komponenten können in verschiedenen Teilen der Anwendung verwendet werden, was zu einer sauberen, modularen Struktur führt.
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
