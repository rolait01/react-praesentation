﻿import React from "react";
import "./PageStyles.css";

export default function JSXKomponenten() {
    return (
        <div className="page-content">
            <div className="page-grid">
                <div className="page-card">
                    <h3 className="card-title">JSX – Was ist das?</h3>
                    <ul className="card-body bullet-list">
                        <li>Syntaxerweiterung für JavaScript.</li>
                        <li>Ermöglicht HTML-ähnliche Strukturen.</li>
                        <li>Wird zu React.createElement kompiliert.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Komponenten-Grundlagen</h3>
                    <ul className="card-body bullet-list">
                        <li>Funktionale &amp; Klassenkomponenten.</li>
                        <li>Props: Datenübergabe Eltern → Kind.</li>
                        <li>Wiederverwendbare UI-Bausteine.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Live-Beispiel</h3>
                    <pre className="code-snippet">
{`// Greeting.jsx
const Greeting = ({ name }) => <h1>Hello, {name}!</h1>;

// index.jsx
import ReactDOM from "react-dom/client";
import React from "react";
import Greeting from "./Greeting";

ReactDOM.createRoot(document.getElementById("root"))
  .render(<Greeting name="World" />);`}
          </pre>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Warum JSX?</h3>
                    <ul className="card-body bullet-list">
                        <li>Erhöht Lesbarkeit des Codes.</li>
                        <li>Nahtloser Wechsel HTML ↔ JS.</li>
                        <li>Dynamische Ausdrücke direkt im Template.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Best Practices</h3>
                    <ul className="card-body bullet-list">
                        <li>Kleine, fokussierte Komponenten.</li>
                        <li>PropTypes/TypeScript für Typ-Safety.</li>
                        <li>Prettier &amp; ESLint für sauberen Code.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Fazit</h3>
                    <ul className="card-body bullet-list">
                        <li>JSX ist das Herzstück von React.</li>
                        <li>HTML &amp; JS elegant kombiniert.</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}
