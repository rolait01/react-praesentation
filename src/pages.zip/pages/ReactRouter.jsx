﻿// src/pages/ReactRouter.jsx
import React from "react";
import "../pages/PageStyles.css";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";

export default function ReactRouterPage() {
    const cards = [
        {
            title: "Was ist React Router?",
            body: (
                <>
                    **React Router** ist eine Standardbibliothek für das Routing in React-Anwendungen.
                    Es ermöglicht das **navigieren zwischen verschiedenen Seiten** in einer Single-Page-Anwendung, ohne die Seite neu zu laden.
                    <br /><br />
                    Es ist besonders nützlich, um Benutzer von einer Seite zur anderen zu führen und eine moderne **Single-Page-Application (SPA)** zu erstellen.
                </>
            ),
        },
        {
            title: "Installation und Setup von React Router",
            body: (
                <>
                    Um React Router zu nutzen, müssen wir es installieren:
                    <pre>{`npm install react-router-dom`}</pre>
                    <br /><br />
                    Dann importieren wir die erforderlichen Komponenten, um Routing in unserer Anwendung zu ermöglichen.
                </>
            ),
        },
        {
            title: "Routen und Navigation",
            body: (
                <>
                    In React Router definieren wir Routen mit dem **`<Route>`**-Tag und verwenden den **`<Link>`**-Tag für die Navigation:
                    <ul>
                        <li><strong>Route:</strong> Definiert die Route, die auf eine bestimmte URL reagiert und eine Komponente rendert.</li>
                        <li><strong>Link:</strong> Wird verwendet, um die URL zu ändern und zwischen den Seiten zu navigieren.</li>
                    </ul>
                    Beispiel:
                    <pre>{`<Link to="/home">Home</Link>`}</pre>
                </>
                    ),
                    },
                    {
                        title: "Switch und BrowserRouter",
                        body: (
                        <>
                        - **`<BrowserRouter>`**: Wrappen Sie die gesamte Anwendung mit `<BrowserRouter>` für die Verwaltung des Browser-Verlaufs.
                        <br /><br />
                        - **`<Switch>`**: Der `<Switch>`-Tag sorgt dafür, dass nur die erste Route angezeigt wird, die der URL entspricht:
                        <pre>{`<Switch>
  <Route path="/home" component={HomePage} />
  <Route path="/about" component={AboutPage} />
</Switch>`}</pre>
                </>
),
},
];

return (
    <div className="react-page-container">
        <div className="react-card-wrapper">
            {cards.map((card, index) => (
                <div key={index} className="react-card">
                    <h2 className="card-title">{card.title}</h2>
                    <div className="card-body">{card.body}</div>
                </div>
            ))}
        </div>

        {/* Beispiel einer Router-Integration */}
        <Router>
            <nav>
                <ul>
                    <li><Link to="/home">Home</Link></li>
                    <li><Link to="/about">About</Link></li>
                </ul>
            </nav>

            <Switch>
                <Route path="/home" component={() => <div>Home Page</div>} />
                <Route path="/about" component={() => <div>About Page</div>} />
            </Switch>
        </Router>
    </div>
);
}
