﻿import React from "react";
import "./PageStyles.css";

export default function SharePoint() {
    return (
        <>
            <div className="page-grid">
                <div className="page-card">
                    <h3 className="card-title">SPFx Setup</h3>
                    <ul className="card-body">
                        <li>Yeoman Generator</li>
                        <li>React Webpart Template</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Webparts</h3>
                    <ul className="card-body">
                        <li>Client-Side Webparts</li>
                        <li>Property Pane Config</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Deployment</h3>
                    <ul className="card-body">
                        <li>SP App Catalog</li>
                        <li>Versionierung</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Context</h3>
                    <ul className="card-body">
                        <li>PageContext</li>
                        <li>Current User</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Branding</h3>
                    <ul className="card-body">
                        <li>Custom CSS/SCSS</li>
                        <li>Office UI Fabric</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Permissions</h3>
                    <ul className="card-body">
                        <li>Graph API Scopes</li>
                        <li>SharePoint Groups</li>
                    </ul>
                </div>
            </div>
        </>
    );
}
