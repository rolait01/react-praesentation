﻿// src/pages/ReactHooks.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function ReactHooks() {
    const cards = [
        {
            title: "Was sind React Hooks?",
            body: (
                <>
                    **React Hooks** sind Funktionen, die es ermöglichen, in **funktionalen Komponenten** Zustand, Nebenwirkungen und andere React-Funktionen zu verwenden, die früher nur in **klassenbasierten Komponenten** verfügbar waren.
                    <br /><br />
                    Hooks ermöglichen es, komplexe Funktionen und Logik in einfache, wiederverwendbare, funktionale Komponenten zu verlagern.
                </>
            ),
        },
        {
            title: "useRef Hook",
            body: (
                <>
                    <ul>
                        <li><strong>useRef:</strong> Ermöglicht den direkten Zugriff auf DOM-Elemente oder das Speichern von Werten über Renderzyklen hinweg.</li>
                        <li>Verwendet für **Referenzen auf DOM-Elemente**, ohne dass die Komponente erneut gerendert wird.</li>
                        <li>Kann auch für **Persistenz von Werten** genutzt werden, die sich nicht ändern sollen, ohne dass sie den Zustand beeinflussen.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "useContext Hook",
            body: (
                <>
                    <ul>
                        <li><strong>useContext:</strong> Ermöglicht den Zugriff auf den globalen Zustand, der über das **Context API** bereitgestellt wird.</li>
                        <li>Ideal, um den Zustand über verschiedene Komponenten hinweg zu teilen, ohne Props explizit weiterzugeben.</li>
                        <li>Verhindert **Props-Drilling**, besonders bei großen und komplexen Anwendungen.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "useReducer Hook",
            body: (
                <>
                    <ul>
                        <li><strong>useReducer:</strong> Eine Alternative zu `useState`, wenn komplexe Zustände oder mehrere Aktionen verwaltet werden müssen.</li>
                        <li>Verwendet einen **Reducer**, um den Zustand zu aktualisieren, was besonders bei komplexen State-Änderungen nützlich ist.</li>
                        <li>Ideal für das Management von **komplexeren Anwendungszuständen** und das Verarbeiten von mehreren Aktionen gleichzeitig.</li>
                    </ul>
                </>
            ),
        },
        {
            title: "Weitere nützliche Hooks",
            body: (
                <>
                    <ul>
                        <li><strong>useMemo:</strong> Wird verwendet, um teure Berechnungen nur dann auszuführen, wenn sich die Eingabewerte ändern.</li>
                        <li><strong>useCallback:</strong> Ermöglicht es, Funktionen nur dann neu zu erstellen, wenn sich die Abhängigkeiten ändern.</li>
                        <li><strong>useLayoutEffect:</strong> Ein effektiverer Hook als `useEffect` für das Arbeiten mit Layout-Änderungen.</li>
                    </ul>
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
