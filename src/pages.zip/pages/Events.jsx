﻿import React from "react";
import "./PageStyles.css";

export default function Events() {
    return (
        <>
            <div className="page-grid">
                <div className="page-card">
                    <h3 className="card-title">onClick</h3>
                    <ul className="card-body">
                        <li>Klick-Handler</li>
                        <li>Event-Objekt</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">onChange</h3>
                    <ul className="card-body">
                        <li>Input-Änderungen</li>
                        <li>Formulare steuern</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">SyntheticEvent</h3>
                    <ul className="card-body">
                        <li>Cross-Browser</li>
                        <li>Pool-System</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Event Bubbling</h3>
                    <ul className="card-body">
                        <li>Propagation</li>
                        <li><code>stopPropagation()</code></li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Keyboard Events</h3>
                    <ul className="card-body">
                        <li>onKeyDown / onKeyUp</li>
                        <li>Key-Codes auswerten</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Debounce & Throttle</h3>
                    <ul className="card-body">
                        <li>Performance-Optimierung</li>
                        <li>scroll / resize Handling</li>
                    </ul>
                </div>
            </div>
        </>
    );
}
