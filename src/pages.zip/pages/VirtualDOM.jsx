﻿// src/pages/VirtualDOM.jsx
import React from "react";
import "../pages/PageStyles.css";

export default function VirtualDOM() {
    const cards = [
        {
            title: "Was ist der Virtual DOM?",
            body: (
                <>
                    Der Virtual DOM ist eine in JavaScript gehaltene Kopie des echten DOMs, das React
                    verwendet, um Änderungen effizienter umzusetzen. Statt den echten DOM bei jeder
                    Änderung komplett neu zu rendern, arbeitet React mit einer virtuellen Repräsentation
                    des DOM.
                </>
            ),
        },
        {
            title: "Der Unterschied zum echten DOM",
            body: (
                <>
                    Das echte DOM wird direkt im Browser gerendert. Bei Änderungen am DOM wird
                    normalerweise das gesamte DOM neu gerendert. React hingegen vergleicht nur die
                    geänderten Teile des Virtual DOM und aktualisiert nur die betroffenen Teile des
                    echten DOM.
                </>
            ),
        },
        {
            title: "Performance-Vorteile",
            body: (
                <>
                    Durch die Verwendung des Virtual DOMs wird die Performance erheblich verbessert,
                    da React nur die Teile des echten DOMs aktualisiert, die sich tatsächlich verändert
                    haben, anstatt das gesamte DOM neu zu rendern.
                </>
            ),
        },
        {
            title: "Wie React den Virtual DOM nutzt",
            body: (
                <>
                    React verwendet die **Reconciliation**-Methode, bei der es das Virtual DOM mit dem
                    vorherigen Zustand vergleicht, um festzustellen, welche Teile des echten DOMs
                    geändert werden müssen. Dieser Prozess macht Updates schneller und effizienter.
                </>
            ),
        },
    ];

    return (
        <div className="react-page-container">
            <div className="react-card-wrapper">
                {cards.map((card, index) => (
                    <div key={index} className="react-card">
                        <h2 className="card-title">{card.title}</h2>
                        <div className="card-body">{card.body}</div>
                    </div>
                ))}
            </div>
        </div>
    );
}
