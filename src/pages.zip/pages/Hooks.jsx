﻿import React from "react";
import "./PageStyles.css";

export default function Hooks() {
    return (
        <div className="page-content">
            <div className="page-grid">
                <div className="page-card">
                    <h3 className="card-title">useState</h3>
                    <ul className="card-body bullet-list">
                        <li>Lokaler Zustand in Funktional-Komponenten.</li>
                        <li>Rückgabe: [state, setState].</li>
                        <li>Rerender bei setState.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">useEffect</h3>
                    <ul className="card-body bullet-list">
                        <li>Side-Effects (Fetch, Timer).</li>
                        <li>Abhängigkeiten-Array steuert Aufrufe.</li>
                        <li>Cleanup-Funktion möglich.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">useContext</h3>
                    <ul className="card-body bullet-list">
                        <li>Zugriff auf React Context.</li>
                        <li>Vermeidet Props-Drilling.</li>
                        <li>Ideal für Themes, Auth.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Custom Hooks</h3>
                    <ul className="card-body bullet-list">
                        <li>Logik in wiederverwendbare Funktionen.</li>
                        <li>Namen beginnen mit „use“. </li>
                        <li>Einfach testbar.</li>
                    </ul>
                </div>

                <div className="page-card">
                    <h3 className="card-title">useEffect-Beispiel</h3>
                    <pre className="code-snippet">
{`import { useState, useEffect } from "react";

function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  return <div>{time.toLocaleTimeString()}</div>;
}`}
          </pre>
                </div>

                <div className="page-card">
                    <h3 className="card-title">Regeln der Hooks</h3>
                    <ul className="card-body bullet-list">
                        <li>Nur auf Top-Level aufrufen.</li>
                        <li>Nur in React-Funktionen nutzen.</li>
                        <li>Abhängigkeiten-Array pflegen.</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}
